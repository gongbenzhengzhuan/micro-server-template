/*
 Navicat Premium Data Transfer

 Source Server         : 21mysql模拟环境
 Source Server Type    : MySQL
 Source Server Version : 80032
 Source Host           : 172.16.12.21:3306
 Source Schema         : xjd_039_zyc_service

 Target Server Type    : MySQL
 Target Server Version : 80032
 File Encoding         : 65001

 Date: 29/03/2023 23:43:54
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for access_records
-- ----------------------------
DROP TABLE IF EXISTS `access_records`;
CREATE TABLE `access_records`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `dedicated_id` int(0) NOT NULL COMMENT '专用库标识',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户标识',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除0是1否',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '路径',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for analysis_task_manage
-- ----------------------------
DROP TABLE IF EXISTS `analysis_task_manage`;
CREATE TABLE `analysis_task_manage`  (
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键id',
  `task_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '解析任务名称',
  `task_description` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '描述信息',
  `scheduling_type` int(0) NOT NULL COMMENT '0 立即执行；1 周期调度',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `analysis_rule` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '解析规则',
  `task_state` double(11, 0) NULL DEFAULT NULL COMMENT '任务状态,0 待执行；1执行中；2执行失败；3执行成功',
  `schedule_state` int(0) NULL DEFAULT 0 COMMENT '调度状态，0启动；1暂停；2重启',
  `data_subject` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '数据主题选择',
  `is_deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `end_time` datetime(0) NULL DEFAULT NULL COMMENT '失效时间',
  `subject_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '解析数据主题id',
  `schedule_cycle` int(0) NULL DEFAULT 2 COMMENT '调度周期，0三个小时，1六个小时，2十二个小时，3二十四个小时',
  `run_interval` int(0) NULL DEFAULT NULL COMMENT '调度周期;单位:秒.如果配置了cron，按cron表达式。如果没有cron，则间隔一点时间跑一次。',
  `cron` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'cron表达式',
  `start_time` datetime(0) NULL DEFAULT NULL COMMENT '生效时间',
  `analysis_rule_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '解析规则名字',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '任务详情表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for approval_pending_manage
-- ----------------------------
DROP TABLE IF EXISTS `approval_pending_manage`;
CREATE TABLE `approval_pending_manage`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `identification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '唯一标识',
  `approval_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '申请编号',
  `bench_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请类型',
  `detail` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请明细',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '申请人id',
  `bench_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请人',
  `create_time` datetime(6) NULL DEFAULT NULL COMMENT '申请时间',
  `os` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '专题数据的唯一标识',
  `node` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '节点',
  `states` int(0) NULL DEFAULT 0 COMMENT '状态 0：待审批 1：已审批 2：撤销',
  `reach_time` datetime(0) NULL DEFAULT NULL COMMENT '到达时间',
  `over_time` datetime(0) NULL DEFAULT NULL COMMENT '结束时间',
  `resource` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '资源名称',
  `code_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '资源代码',
  `department` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '所属部门',
  `approval_specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '审批说明',
  `result` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '结果',
  `update_time` datetime(0) NULL DEFAULT NULL,
  `operation_detail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '业务明细',
  `module` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '模块，中台，图谱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2112704689 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '工作台' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for approval_pending_manage_copy
-- ----------------------------
DROP TABLE IF EXISTS `approval_pending_manage_copy`;
CREATE TABLE `approval_pending_manage_copy`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '申请编号',
  `applicationcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '申请编码',
  `bench_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请类型',
  `detail` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请明细',
  `bench_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请人',
  `applicant_department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '申请人部门',
  `identification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `os` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作',
  `personnel_involved` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '涉及人员',
  `department` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '所属部门',
  `node` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '节点',
  `states` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '状态 1：已审批   2：待审批',
  `create_time` datetime(6) NULL DEFAULT NULL COMMENT '申请时间',
  `reach_time` datetime(0) NULL DEFAULT NULL COMMENT '到达时间',
  `over_time` datetime(0) NULL DEFAULT NULL COMMENT '结束时间',
  `resource` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '资源代码',
  `code_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '资源名称',
  `approval_specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '审批说明',
  `result` int(0) NULL DEFAULT 0 COMMENT '结果 ：0 待审核  1  驳回   2通过',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 32135 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '工作台' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for audit_code
-- ----------------------------
DROP TABLE IF EXISTS `audit_code`;
CREATE TABLE `audit_code`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `suid` int(0) NULL DEFAULT NULL COMMENT '审核表主键',
  `index_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '索引名字 (文章详情)',
  `oid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'oid  文章详情页',
  `update_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户账号  (文章详情)',
  `visible_scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '可见范围 1：个人 2：科室 3：全局  (文章详情 事件详情)',
  `zysjk_visible` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '可见专用库 (文章详情页)',
  `zysjk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专用库  (文章详情  事件详情页)',
  `eid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专题数据ID  (事件详情)',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户账号 (事件详情页)',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除（是：1，否：0）',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户端 审核编码表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for banner_task
-- ----------------------------
DROP TABLE IF EXISTS `banner_task`;
CREATE TABLE `banner_task`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `position` int(0) NOT NULL COMMENT '关联位置(顶部banne:1,轮播大图:2)',
  `ordered` tinyint(0) NOT NULL COMMENT '顺序',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '轮播图url',
  `online_date` datetime(0) NULL DEFAULT NULL COMMENT '上线时间',
  `special_library_id` int(0) NOT NULL COMMENT '专用库id',
  `data_source_id` int(0) NULL DEFAULT NULL COMMENT '文章数据源id',
  `document_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文章标题',
  `document_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文章id',
  `document_index` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文章索引',
  `document_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文章url',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `enabled` int(0) NOT NULL COMMENT '是否启用（是：1，否：0）',
  `summary` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '摘要',
  `text_tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文本标签',
  `source_platform` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '来源平台',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 483 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '总览页设置-任务列表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for banner_task_document（废弃）
-- ----------------------------
DROP TABLE IF EXISTS `banner_task_document（废弃）`;
CREATE TABLE `banner_task_document（废弃）`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `task_id` int(0) NOT NULL COMMENT '任务id',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文章标题',
  `document_id` int(0) NOT NULL COMMENT '文章id',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文章url',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '总览页设置-任务列表-指定文章列表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for contribution
-- ----------------------------
DROP TABLE IF EXISTS `contribution`;
CREATE TABLE `contribution`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `special_library_id` int(0) NOT NULL COMMENT '专用库ID',
  `document_type` int(0) NOT NULL COMMENT '类型',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `operate_type` int(0) NOT NULL COMMENT '修改类型',
  `effective_scope` int(0) NOT NULL COMMENT '生效范围',
  `approval_states` int(0) NULL DEFAULT NULL COMMENT '审批状态 1:通过 2:驳回',
  `approval_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '审批人',
  `create_time` datetime(0) NOT NULL COMMENT '时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '我的贡献' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for crowdsourcing_comment
-- ----------------------------
DROP TABLE IF EXISTS `crowdsourcing_comment`;
CREATE TABLE `crowdsourcing_comment`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `aid` int(0) NULL DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for crowdsourcing_knowledge
-- ----------------------------
DROP TABLE IF EXISTS `crowdsourcing_knowledge`;
CREATE TABLE `crowdsourcing_knowledge`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `similarity` int(0) NULL DEFAULT NULL COMMENT '相似度',
  `answer_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '回答标题',
  `answer_similarity` int(0) NULL DEFAULT NULL COMMENT '回答 相关度',
  `reply_time` datetime(0) NULL DEFAULT NULL COMMENT '回答时间',
  `hotest_answer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '最热答案',
  `answer_time` datetime(0) NULL DEFAULT NULL COMMENT '答案时间',
  `answer_collection` int(0) NULL DEFAULT 0 COMMENT '答案收藏数',
  `answer_likes` int(0) NULL DEFAULT 0 COMMENT '答案点赞数',
  `answer_comment` int(0) NULL DEFAULT 0 COMMENT '答案评论数',
  `Indexes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '索引',
  `answer_total` int(0) NULL DEFAULT NULL COMMENT '回答总数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '众包知识表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for crowdsourcing_knowledge_answer
-- ----------------------------
DROP TABLE IF EXISTS `crowdsourcing_knowledge_answer`;
CREATE TABLE `crowdsourcing_knowledge_answer`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sid` int(0) NULL DEFAULT NULL COMMENT 'sid主键',
  `hotest_answer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `answer_time` datetime(0) NULL DEFAULT NULL COMMENT '答案时间',
  `answer_collection` int(0) NULL DEFAULT 0 COMMENT '答案收藏数',
  `answer_likes` int(0) NULL DEFAULT 0 COMMENT '答案点赞数',
  `answer_comment` int(0) NULL DEFAULT 0 COMMENT '答案评论数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '众包知识表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for factual_atlas
-- ----------------------------
DROP TABLE IF EXISTS `factual_atlas`;
CREATE TABLE `factual_atlas`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `node` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '节点',
  `happen_time` datetime(0) NULL DEFAULT NULL COMMENT '发生时间',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '类型',
  `type_case` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '类型-原因（比如前因类）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '事理图谱表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for factual_atlas_detailed
-- ----------------------------
DROP TABLE IF EXISTS `factual_atlas_detailed`;
CREATE TABLE `factual_atlas_detailed`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `fid` int(0) NOT NULL COMMENT '事理图谱关联主键id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '原因',
  `target` int(0) NULL DEFAULT NULL COMMENT '上层节点',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '造成/引发/导致',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  `source` int(0) NULL DEFAULT NULL COMMENT '下层节点',
  `type_case` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '类型 - 原因',
  `source_root` int(0) NULL DEFAULT NULL COMMENT '根事件节点',
  `text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '移入显示的文字',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for image_text
-- ----------------------------
DROP TABLE IF EXISTS `image_text`;
CREATE TABLE `image_text`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文字',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for keyword_exclude
-- ----------------------------
DROP TABLE IF EXISTS `keyword_exclude`;
CREATE TABLE `keyword_exclude`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '排除关键字',
  `configuration_item_id` int(0) NOT NULL COMMENT '关联专用库配置项id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 647 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for keyword_include
-- ----------------------------
DROP TABLE IF EXISTS `keyword_include`;
CREATE TABLE `keyword_include`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '包含关键字',
  `configuration_item_id` int(0) NOT NULL COMMENT '关联专用库配置项id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1102 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for keyword_include_must
-- ----------------------------
DROP TABLE IF EXISTS `keyword_include_must`;
CREATE TABLE `keyword_include_must`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '必须包含关键字',
  `configuration_item_id` int(0) NOT NULL COMMENT '关联专用库配置项id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 140 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for label_feature
-- ----------------------------
DROP TABLE IF EXISTS `label_feature`;
CREATE TABLE `label_feature`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `is_deleted` int(0) NULL DEFAULT 0 COMMENT '是否逻辑删除，0未删除，1删除',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标签',
  `label_id` int(0) NULL DEFAULT NULL COMMENT '标签主键',
  `feature_words` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '特征词,1是数据包中提取的,2是从人工添加的',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `data_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '数据包名字',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for label_manage
-- ----------------------------
DROP TABLE IF EXISTS `label_manage`;
CREATE TABLE `label_manage`  (
  `id` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
  `is_deleted` int(0) NULL DEFAULT 0 COMMENT '是否逻辑删除，0未删除，1删除',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标签',
  `level` int(0) NULL DEFAULT NULL COMMENT '目录',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `parent_id` int(0) NULL DEFAULT NULL COMMENT '父主键',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `label_type` int(0) NULL DEFAULT NULL COMMENT '1：分类，2：标签',
  `english_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '英文名',
  `described` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '描述',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '来源',
  `parent_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '父分类的姓名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 80 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lable_analysis
-- ----------------------------
DROP TABLE IF EXISTS `lable_analysis`;
CREATE TABLE `lable_analysis`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `article` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文章内容',
  `relationship` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标签',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '关键词',
  `states` int(0) NULL DEFAULT NULL COMMENT '特征词的抽取状态（1.已抽取  2.待抽取）',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除（0.否  1.是）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lable_classify
-- ----------------------------
DROP TABLE IF EXISTS `lable_classify`;
CREATE TABLE `lable_classify`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `classify` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '分类名',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT NULL COMMENT '是否删除 （0.否  1.是）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for labled
-- ----------------------------
DROP TABLE IF EXISTS `labled`;
CREATE TABLE `labled`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '中文名',
  `english_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '英文名',
  `classify_id` int(0) NULL DEFAULT NULL COMMENT '所属分类的id',
  `described` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '描述',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '来源',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除（0.否  1.是）',
  `classify_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for localimport
-- ----------------------------
DROP TABLE IF EXISTS `localimport`;
CREATE TABLE `localimport`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标题',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `keywords` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '关键字',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NOT NULL DEFAULT 0 COMMENT '是否删除（0.否  1.是）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for manage
-- ----------------------------
DROP TABLE IF EXISTS `manage`;
CREATE TABLE `manage`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `manage_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '管理者名称',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `state` int(0) NULL DEFAULT 0 COMMENT '0 未生效  1 生效',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for manage_lable
-- ----------------------------
DROP TABLE IF EXISTS `manage_lable`;
CREATE TABLE `manage_lable`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `relationship` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标签',
  `characteristic_words` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '特征词',
  `category` int(0) NULL DEFAULT 1 COMMENT '类别（1.从文章中抽取的特征词   2.自己添加的特征词）',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除（0.否 1.是）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for manage_user
-- ----------------------------
DROP TABLE IF EXISTS `manage_user`;
CREATE TABLE `manage_user`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `mid` int(0) NULL DEFAULT NULL COMMENT '管理表主键',
  `uid` int(0) NULL DEFAULT NULL COMMENT '用户表主键',
  `state` int(0) NULL DEFAULT 0 COMMENT '0 未生效  1 已生效',
  `be_deleted` int(0) NULL DEFAULT 0 COMMENT '待删除  1 待删除',
  `identification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 229 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '管理-用户' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for multiple_draft
-- ----------------------------
DROP TABLE IF EXISTS `multiple_draft`;
CREATE TABLE `multiple_draft`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `config_id` int(0) NOT NULL COMMENT '主表id',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'tab标题',
  `data_source_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '数据源名称',
  `data_source_id` int(0) NOT NULL COMMENT '数据源',
  `ordered` tinyint(0) NOT NULL DEFAULT 1 COMMENT '顺序',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3053 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '总览页装修-文稿' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for multiple_draft_config
-- ----------------------------
DROP TABLE IF EXISTS `multiple_draft_config`;
CREATE TABLE `multiple_draft_config`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文稿标题',
  `source_id` int(0) NOT NULL COMMENT '专用库或者主题id',
  `view_count` int(0) NOT NULL COMMENT '展示条数',
  `multiple` int(0) NOT NULL COMMENT '是否多文稿(热门标签:1,多文稿标签:2,主题文稿:3)',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1476 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '总览页装修-文稿-配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for my_file
-- ----------------------------
DROP TABLE IF EXISTS `my_file`;
CREATE TABLE `my_file`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `special_library_id` int(0) NULL DEFAULT NULL COMMENT '专用库',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id',
  `url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '上传rul',
  `data_type` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '数据类型',
  `file_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '导入文件',
  `data_analysis` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '数据解析',
  `approval_states` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '审批状态 1:通过 2:未审批',
  `os` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作',
  `create_time` datetime(0) NOT NULL COMMENT '导入时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for natural_search
-- ----------------------------
DROP TABLE IF EXISTS `natural_search`;
CREATE TABLE `natural_search`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `search` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '搜索语句',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for option_choose
-- ----------------------------
DROP TABLE IF EXISTS `option_choose`;
CREATE TABLE `option_choose`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `configuration_item_id` int(0) NOT NULL COMMENT '关联专用库配置项id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id',
  `configuration_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置类型',
  `dict_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '字典码',
  `configuration_data` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置数据',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 789 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for option_configuration
-- ----------------------------
DROP TABLE IF EXISTS `option_configuration`;
CREATE TABLE `option_configuration`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `configuration_item_id` int(0) NOT NULL COMMENT '关联专用库配置项id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id',
  `configuration_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置类型',
  `configuration_data` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置数据',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 56 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for option_list
-- ----------------------------
DROP TABLE IF EXISTS `option_list`;
CREATE TABLE `option_list`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `option_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类别名称',
  `dict_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字典码(key)',
  `option_data` varchar(3000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置数据',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '搜索项列表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `available` int(0) NULL DEFAULT 1 COMMENT '状态 :当前管理员是否可以选用 0 不可用 1 功能管理员 2 借调访客权限',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 101 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '权限表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for permission_list
-- ----------------------------
DROP TABLE IF EXISTS `permission_list`;
CREATE TABLE `permission_list`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `iid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `resource_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '资源类型',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '路径',
  `permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '权限字符串',
  `parentld` int(0) NULL DEFAULT 0 COMMENT '父编号',
  `parentlds` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '父编号权限',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `available` int(0) NULL DEFAULT 1 COMMENT '状态 :当前管理员是否可以选用 0 不可用 1 功能管理员 2 借调访客权限',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `role` int(0) NULL DEFAULT NULL COMMENT '0 用户端  1 管理端的',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 97 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '权限表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for permission_manage
-- ----------------------------
DROP TABLE IF EXISTS `permission_manage`;
CREATE TABLE `permission_manage`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `mid` int(0) NULL DEFAULT NULL COMMENT '权限id',
  `pid` int(0) NULL DEFAULT NULL COMMENT '权限表id',
  `identification` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '添加时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `state` int(0) NOT NULL DEFAULT 0 COMMENT '状态: 0、添加待审批 1、添加失败 2、更新待审批  3、更新失败  4、审批通过',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 498 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '权限角色中间表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for permission_role
-- ----------------------------
DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE `permission_role`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `rid` int(0) NULL DEFAULT NULL COMMENT '角色表id',
  `pid` int(0) NULL DEFAULT NULL COMMENT '权限表id',
  `identification` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '添加时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `state` int(0) NOT NULL DEFAULT 0 COMMENT '状态: 0、添加待审批 1、添加失败 2、更新待审批  3、更新失败  4、审批通过',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 92 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '权限角色中间表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `rid` int(0) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色描述',
  `state` int(0) NULL DEFAULT 0 COMMENT '前端状态:状态: 0、待审批 1、审批失败 2审批成功\"',
  `available` int(0) NULL DEFAULT 0 COMMENT '状态 :当前管理员是否可以选用  0能 1不能',
  `created_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建人',
  `exhibition` int(0) NULL DEFAULT NULL COMMENT '授权权限:  0免密级别  1机密级别 2绝密级别',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `s_state` int(0) NULL DEFAULT 0 COMMENT '使用状态  0 新数据   1   旧数据 ',
  PRIMARY KEY (`rid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '角色' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for role_draft
-- ----------------------------
DROP TABLE IF EXISTS `role_draft`;
CREATE TABLE `role_draft`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `rid` int(0) NULL DEFAULT NULL COMMENT '角色主键',
  `role_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色描述',
  `exhibition` int(0) NULL DEFAULT NULL COMMENT '授权权限:  0免密级别  1机密级别 2绝密级别',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `state` int(0) NULL DEFAULT NULL COMMENT '当前状态  0 草稿  1 丢弃',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '角色草稿箱' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for score_config
-- ----------------------------
DROP TABLE IF EXISTS `score_config`;
CREATE TABLE `score_config`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `operation_type` int(0) NOT NULL COMMENT '操作类型(编辑,新增,批注,上传等)',
  `document_type` int(0) NOT NULL COMMENT '文章类型',
  `score` int(0) NOT NULL COMMENT '分数',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '积分设置表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for score_logs
-- ----------------------------
DROP TABLE IF EXISTS `score_logs`;
CREATE TABLE `score_logs`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `operation_type` int(0) NOT NULL COMMENT '修改类型(编辑,新增,批注,上传等)',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `document_type` int(0) NOT NULL COMMENT '类型',
  `score` int(0) NOT NULL COMMENT '分数',
  `special_library_id` int(0) NOT NULL COMMENT '专用库id',
  `user_id` int(0) NOT NULL COMMENT '用户id',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '积分记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for search_log
-- ----------------------------
DROP TABLE IF EXISTS `search_log`;
CREATE TABLE `search_log`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '搜索人',
  `search_keywords` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '搜索关键字',
  `search_num` int(0) NULL DEFAULT NULL COMMENT '命中数量',
  `roles` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属角色',
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属组织',
  `application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '发起应用',
  `search_category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '搜索分类',
  `terminal_marking` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '终端标识',
  `terminal_equipment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '终端设备名',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'ip地址',
  `mac_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'mac地址',
  `key_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'key号',
  `operation_time` datetime(0) NULL DEFAULT NULL COMMENT '操作时间',
  `operation_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作内容',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 158 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '搜索日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for search_term
-- ----------------------------
DROP TABLE IF EXISTS `search_term`;
CREATE TABLE `search_term`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `dict_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字典编码标识',
  `page_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '页面标识',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '搜索条件配置表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library
-- ----------------------------
DROP TABLE IF EXISTS `special_library`;
CREATE TABLE `special_library`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `special_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专用库编码',
  `special_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专用库名称',
  `identification` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `creater` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建人',
  `state` int(0) NULL DEFAULT 0 COMMENT '状态: -1 删除审核中  0、发布待审核 1、发布失败 2、更新待审核  3、更新失败  4、已发布',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '图片地址',
  `special_describe` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专用库描述',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '/twLibrary' COMMENT '路径',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 155 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专用库表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_base_info
-- ----------------------------
DROP TABLE IF EXISTS `special_library_base_info`;
CREATE TABLE `special_library_base_info`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键id(自增)',
  `special_library_id` int(0) NOT NULL COMMENT '专用库标识',
  `contents` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主题名称',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主题名称',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除0否1是',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_data_configuration
-- ----------------------------
DROP TABLE IF EXISTS `special_library_data_configuration`;
CREATE TABLE `special_library_data_configuration`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `configuration_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置项名称',
  `state` int(0) NULL DEFAULT NULL COMMENT '状态0.未配置1.已配置',
  `special_library_id` int(0) NULL DEFAULT NULL COMMENT '专用库id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id',
  `version` int(0) NOT NULL DEFAULT 0 COMMENT '配置项类型 0业务数据 1开源数据',
  `type_signage` int(0) NULL DEFAULT 1 COMMENT '专用库配置类型标识 1.配置（默认） 2.普通专题  3.文献专题',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 724 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_data_configuration2
-- ----------------------------
DROP TABLE IF EXISTS `special_library_data_configuration2`;
CREATE TABLE `special_library_data_configuration2`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `organizer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '承办单位',
  `business` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '业务方向',
  `event_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '事件名称',
  `start_time` datetime(0) NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime(0) NULL DEFAULT NULL COMMENT '结束时间',
  `related_people` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '相关人物',
  `regions_involved` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '涉及地区',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专用库管理  业务数据配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_draft
-- ----------------------------
DROP TABLE IF EXISTS `special_library_draft`;
CREATE TABLE `special_library_draft`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `special_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专用库编码',
  `special_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专用库名称',
  `state` int(0) NULL DEFAULT NULL COMMENT ' 0未修改 1  有修改  ',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `sid` int(0) NULL DEFAULT NULL COMMENT '专用库主键',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 114 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专用库表-草稿' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_search_history
-- ----------------------------
DROP TABLE IF EXISTS `special_library_search_history`;
CREATE TABLE `special_library_search_history`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id',
  `search_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '搜索类型',
  `search_condition` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '搜索条件',
  `result_num` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '结果数量',
  `request_initiator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '请求发起者',
  `equipment_ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备IP',
  `mac_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'mac地址',
  `equipment_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备名称',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '搜索链接',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专用库搜索记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_update_records
-- ----------------------------
DROP TABLE IF EXISTS `special_library_update_records`;
CREATE TABLE `special_library_update_records`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `operator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作人',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作类型',
  `operation_details` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作明细',
  `uid` int(0) NULL DEFAULT NULL COMMENT '用户主键',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名称',
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属部门',
  `identification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `sid` int(0) NULL DEFAULT NULL COMMENT '专用库主键',
  `special_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专用库名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 583 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专用库更新记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_user
-- ----------------------------
DROP TABLE IF EXISTS `special_library_user`;
CREATE TABLE `special_library_user`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `modify_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '修改源',
  `modify_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '修改内容',
  `modification_scop` int(0) NULL DEFAULT NULL COMMENT '修改范围: 0 文章详情修改   1:人物修改  国家修改  地区修改 组织修改  6  新增',
  `identification` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `effective_scope` int(0) NULL DEFAULT NULL COMMENT '生效范围  1个人生效  2专用库生效    3  全局生效',
  `state` int(0) NULL DEFAULT 0 COMMENT '状态:  0 待审核 1  驳回 2 通过   ',
  `creater` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '申请人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `userid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '申请人账号',
  `sid` int(0) NULL DEFAULT NULL COMMENT '专用库id',
  `json_str` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'json字符存储',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户端 专用库审核' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_user_info
-- ----------------------------
DROP TABLE IF EXISTS `special_library_user_info`;
CREATE TABLE `special_library_user_info`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sid` int(0) NULL DEFAULT NULL COMMENT '专用库主键',
  `uid` int(0) NULL DEFAULT NULL COMMENT '用户表id',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名称',
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属部门',
  `state` int(0) NULL DEFAULT 0 COMMENT '状态: 0、发布待审核 1、发布失败 2、更新待审核  3、更新失败  4、已发布',
  `special_role` int(0) NULL DEFAULT NULL COMMENT '0 借调访客  1 普通用户 2 专用库管理员',
  `identification` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除  2待添加',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 641 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专用户用户中间表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_library_user_info_copy
-- ----------------------------
DROP TABLE IF EXISTS `special_library_user_info_copy`;
CREATE TABLE `special_library_user_info_copy`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `special_library_id` int(0) NULL DEFAULT NULL COMMENT '专用库主键',
  `usef_info_id` int(0) NULL DEFAULT NULL COMMENT '用户表id',
  `userinfo_role` int(0) NULL DEFAULT 0 COMMENT '专用库用户角色: 0 普通用户  1  借调访客',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专用户用户中间表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_subject
-- ----------------------------
DROP TABLE IF EXISTS `special_subject`;
CREATE TABLE `special_subject`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属类型(例如 人物 事件)',
  `sub_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '对应类型的子类型',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否删除（是：1，否：0）',
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `tid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '类型对应的id 比如人物id',
  `sid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '子类型对应的id',
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '反馈人',
  `is_completed` int(0) NULL DEFAULT 0 COMMENT '0未完成，1完成',
  `source_application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '来源应用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 76 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_topic_file_character
-- ----------------------------
DROP TABLE IF EXISTS `special_topic_file_character`;
CREATE TABLE `special_topic_file_character`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `user_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `sex` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '性别',
  `nationality` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '国籍',
  `user_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '人物类型',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '需求备注',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '上传路径',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专题上传文件-人物' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_topic_file_country
-- ----------------------------
DROP TABLE IF EXISTS `special_topic_file_country`;
CREATE TABLE `special_topic_file_country`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `country_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '国家名称',
  `continent` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '大洲',
  `country_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '需求备注',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '上传路径',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专题上传文件-国家地区' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_topic_file_document
-- ----------------------------
DROP TABLE IF EXISTS `special_topic_file_document`;
CREATE TABLE `special_topic_file_document`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `author` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '作者',
  `nationality` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '国籍',
  `doc_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文献类型',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文献来源',
  `tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文献标签',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '需求备注',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '上传路径',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专题上传文件-文献' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_topic_file_event
-- ----------------------------
DROP TABLE IF EXISTS `special_topic_file_event`;
CREATE TABLE `special_topic_file_event`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `event_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '事件名称',
  `area` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '发生地',
  `event_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '事件类型',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '需求备注',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '上传路径',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专题上传文件-事件' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for special_topic_file_org
-- ----------------------------
DROP TABLE IF EXISTS `special_topic_file_org`;
CREATE TABLE `special_topic_file_org`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `org_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '组织名称',
  `org_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '组织类型',
  `nationality` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '所属国家',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '需求备注',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '上传路径',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '专题上传文件-组织' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `dict_parent_code` bigint(0) NOT NULL COMMENT '父级字典分类编码，例子1：0，例子2：10000',
  `dict_code` bigint(0) NOT NULL COMMENT '字典分类编码，例子1：10000；例子2：10001',
  `dict_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典名称',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1' COMMENT '状态，0-无效，1-有效',
  `insert_time` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '插入时间',
  `update_time` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '系统数据字典表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for system_log
-- ----------------------------
DROP TABLE IF EXISTS `system_log`;
CREATE TABLE `system_log`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户姓名',
  `role_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属角色名称',
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属部门名称',
  `subsystem` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '子系统',
  `module` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属模块',
  `operation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作类型',
  `operation_result` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作结果',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'ip',
  `mac_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'mac地址',
  `key_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'key号',
  `operation_time` datetime(0) NULL DEFAULT NULL COMMENT '操作时间',
  `operation_date` date NULL DEFAULT NULL COMMENT '操作日期',
  `operation_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作内容',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10991 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '系统日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for system_log_archive
-- ----------------------------
DROP TABLE IF EXISTS `system_log_archive`;
CREATE TABLE `system_log_archive`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户姓名',
  `role_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属角色名称',
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属部门名称',
  `subsystem` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '子系统',
  `module` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属模块',
  `operation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作类型',
  `operation_result` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作结果',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'ip',
  `mac_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'mac地址',
  `key_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'key号',
  `operation_time` datetime(0) NULL DEFAULT NULL COMMENT '操作时间',
  `operation_date` date NULL DEFAULT NULL COMMENT '操作日期',
  `operation_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作内容',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 234740 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '系统日志归档表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for test
-- ----------------------------
DROP TABLE IF EXISTS `test`;
CREATE TABLE `test`  (
  `id` int(0) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for test_generator
-- ----------------------------
DROP TABLE IF EXISTS `test_generator`;
CREATE TABLE `test_generator`  (
  `id` int(0) NOT NULL,
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_color
-- ----------------------------
DROP TABLE IF EXISTS `theme_color`;
CREATE TABLE `theme_color`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `color` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '主题色值',
  `enabled` bit(1) NULL DEFAULT NULL COMMENT '是否启用（是：1，否：0）',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `deleted` bit(1) NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '总览页设置-主题色设置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_data_configuration
-- ----------------------------
DROP TABLE IF EXISTS `theme_data_configuration`;
CREATE TABLE `theme_data_configuration`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键id(自增)',
  `configuration_item` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主题名称',
  `special_library_id` int(0) NOT NULL COMMENT '专用库标识',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户标识',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除0否1是',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 187 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_exclude_keywords
-- ----------------------------
DROP TABLE IF EXISTS `theme_exclude_keywords`;
CREATE TABLE `theme_exclude_keywords`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '排除关键词',
  `theme_configuration_id` int(0) NOT NULL COMMENT '主题配置id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户标识',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 80 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_hot_words
-- ----------------------------
DROP TABLE IF EXISTS `theme_hot_words`;
CREATE TABLE `theme_hot_words`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '热词',
  `rolling_new` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '热词滚动新增0无1有',
  `new_duration_type` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '热词新增时长类别0每天1每三天2每周3自定义',
  `theme_configuration_id` int(0) NOT NULL COMMENT '主题数据配置id',
  `is_include` int(0) NOT NULL DEFAULT 0 COMMENT '包含排除标识 0 包含，1排除',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户标识',
  `create_time` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` timestamp(6) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 96 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_include_keywords
-- ----------------------------
DROP TABLE IF EXISTS `theme_include_keywords`;
CREATE TABLE `theme_include_keywords`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '包含关键词',
  `theme_configuration_id` int(0) NOT NULL COMMENT '主题数据配置id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户标识',
  `create_time` datetime(6) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(6) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 243 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_include_keywords_must
-- ----------------------------
DROP TABLE IF EXISTS `theme_include_keywords_must`;
CREATE TABLE `theme_include_keywords_must`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '包含关键词',
  `theme_configuration_id` int(0) NOT NULL COMMENT '主题数据配置id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户标识',
  `create_time` datetime(6) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(6) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 61 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_label_configuration
-- ----------------------------
DROP TABLE IF EXISTS `theme_label_configuration`;
CREATE TABLE `theme_label_configuration`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `theme_configuration_id` int(0) NULL DEFAULT NULL COMMENT '主题数据配置id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户标识',
  `configuration_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置类型',
  `configuration_data` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置数据',
  `create_time` datetime(6) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(6) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_label_selection
-- ----------------------------
DROP TABLE IF EXISTS `theme_label_selection`;
CREATE TABLE `theme_label_selection`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `theme_configuration_id` int(0) NULL DEFAULT NULL COMMENT '主题数据配置id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户标识',
  `configuration_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置类型',
  `dict_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '字典码',
  `configuration_data` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置数据',
  `create_time` datetime(6) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(6) NULL DEFAULT NULL COMMENT '修改时间',
  `deleted` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 595 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_special_topic_config
-- ----------------------------
DROP TABLE IF EXISTS `theme_special_topic_config`;
CREATE TABLE `theme_special_topic_config`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '专题标题',
  `special_library_id` int(0) NOT NULL COMMENT '专用库id',
  `data_source_id` int(0) NOT NULL COMMENT '专题id',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 297 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '总览页装修-专题-配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for theme_special_topic_data_source
-- ----------------------------
DROP TABLE IF EXISTS `theme_special_topic_data_source`;
CREATE TABLE `theme_special_topic_data_source`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `config_id` int(0) NOT NULL COMMENT '主表id',
  `data_source_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '数据源名称',
  `data_source_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '数据源',
  `ordered` tinyint(0) NOT NULL COMMENT '顺序',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（是：1，否：0）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '总览页装修-专题数据源' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for topic_annex
-- ----------------------------
DROP TABLE IF EXISTS `topic_annex`;
CREATE TABLE `topic_annex`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `topic_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专题对象ID',
  `oid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '版本ID',
  `scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '查看范围',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '附件标题',
  `author` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '附件作者',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '附件地址',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for topic_knowledge
-- ----------------------------
DROP TABLE IF EXISTS `topic_knowledge`;
CREATE TABLE `topic_knowledge`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `topic_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专题对象ID',
  `oid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '版本ID',
  `knowledge_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '知识对象ID',
  `knowledge_type` int(0) NULL DEFAULT 0 COMMENT '知识对象类型 0相关知识 1同类知识',
  `knowledge_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '知识对象名称',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '图片地址',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'userId',
  `special_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专用库编码',
  `visibility` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '可见范围: 个人可见:GRKJ, 专用库可见:ZYKKJ, 全局可见:QJKJ',
  `summary` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '简介',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19378 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for topic_object
-- ----------------------------
DROP TABLE IF EXISTS `topic_object`;
CREATE TABLE `topic_object`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `topic_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专题对象id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专题对象名称',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '专题对象图片',
  `special_library_id` int(0) NULL DEFAULT NULL COMMENT '专用库id',
  `topic_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '专题类型',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL COMMENT '修改时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '删除字段 0未删除  1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名称',
  `userid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户账号',
  `department` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属部门',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `state` int(0) NULL DEFAULT 0 COMMENT '状态: 0、添加待审批 1、审核失败 2、审批通过',
  `ip_addr` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '格尔网关 用户ip',
  `key_num` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '格尔网关 用户编号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `uid` int(0) NULL DEFAULT NULL COMMENT '用户表主键',
  `rid` int(0) NULL DEFAULT NULL COMMENT '角色表主键',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名称',
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '所属部门',
  `identification` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  `deleted` int(0) NULL DEFAULT 0 COMMENT '是否删除，0未删除，1删除',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `state` int(0) NULL DEFAULT 0 COMMENT '状态: 0、发布待审核 1、发布失败 2、更新待审核  3、更新失败  4、已发布',
  `edit` int(0) NULL DEFAULT 0 COMMENT '0  其他角色  1 安全员  审计员  系统管理员',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 457 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户角色中间表' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
